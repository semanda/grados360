﻿<html>
<body>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Foreign Exchange Market And Rates Trading System</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<link href="style/calendar.css" rel="stylesheet" type="text/css" media="screen"/>
<script type="text/javascript" src="script/calendar.js"></script>

<div id="header">
	<BR><BR>
	<center><b><font color="Sienna" size="4"  FONT FACE=andalus></font></b></center>
</head>
</div>

<div id="menu">
	<center><ul>

		<li class="first"><a href="home.php">HOME</a></li>
		<li><a href="viewcustomer.php">CUSTOMERS</a></li>
		<li><a href="rate.php">SELLING RATES</a></li>
		<li><a href="delivery.php">BUYING RATES</a></li>
		<li><a href="viewtrans.php">TRANSACTIONS</a></li>
		</ul></center>
</div>
<div id="page">
	<div id="page-top">
		<div id="page-bottom">
		<div>
			<div id="sidebar">
		
				


			
		<img src="mainpic.jpg" width="750" name="dob" onClick="displayDatePicker('dob');" class="text">



			
		</div>
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
</div>
</div>
<div id="footer">
	<b><p>Copyright &copy; 2014 Foreign Exchange Market And Rates Trading System </p></b>
</div>
</body>
</html>
