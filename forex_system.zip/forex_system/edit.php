<?php
  require ("db.php");  

	$Id=$_REQUEST['id'];
     	 
                mysql_query("UPDATE transactions
                            SET status = 'Approved' 
                            WHERE Id = '$Id'") or die(mysql_error());
							echo "<script>window.location.href='Viewtrans.php'</script>";
				echo "Succesfully Aproved";
            
            
            ?>
            