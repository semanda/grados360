<html>
<head>
<meta http-equiv='content-type' content='text/html; charset=utf-8'/><title>Customer Entry</title>
<meta name='keywords' content=''/><meta name='description' content=''/>

<link href='style.css' rel='stylesheet' type='text/css' media='screen'/>
<script type="text/javascript">
function validateForm()
{
var x=document.forms["myForm"]["fname"].value;
if (x==null || x=="")
  {
  alert("symbol must be filled out");
  return false;
  }
var x=document.forms["myForm"]["currency"].value;
if (x==null || x=="")
  {
  alert("Currency must be filled out");
  return false;
  }
var x=document.forms["myForm"]["rate"].value;
if (x==null || x=="")
  {
  alert("Rate Number must be filled out");
  return false;
  }
var x=document.forms["myForm"]["brate"].value;
if (x==null || x=="")
  {
  alert("Buy Rate must be filled out");
  return false;
  }
var x=document.forms["myForm"]["foname"].value;
if (x==null || x=="")
  {
  alert("Forex Name must be filled out");
  return false;
  }
}
</script>

</head>
<body>
<div id='header'>
</div>

<div id='menu'>
		
		<center><ul>

		<li class="first"><a href="home.php">HOME</a></li>
		<li><a href="viewcustomer.php">CUSTOMERS</a></li>
		<li><a href="rate.php">SELLING RATES</a></li>
		<li><a href="delivery.php">BUYING RATES</a></li>
		<li><a href="viewtrans.php">TRANSACTIONS</a></li>
		</ul></center>
</div>

<div id='page'>
	<div style='background-color:WHITE'>

<br>
<center>
  <font color=blue size=5 face=impact> BUY RATES ENTRY</font>
</center>
<br>
<hr color="#006600">
<form name="myForm" action="addbuy.php" method="post" enctype="multipart/form-data" name="addroom" onsubmit="return validateForm()">
<center><table width='730' border='0' cellpadding='4' cellspacing='10' align='center'> 

<tr>
<td>Symbol: </td>
<td><input name="fname" type="text" pattern="[A-Za-z A-Za-z]*" id="textbox" required/></td>
</tr>
<tr>
<td>Currency: </td>
<td><input name="currency" type="text" pattern="[A-Za-z A-Za-z]*" id="textbox" required /></td>
</tr>
<tr>
<td>Sell Rate: </td>
<td><input name="brate" type="text" pattern="[0-9]*" id="textbox" required/></td>
</tr>
<tr>
<td>Forex Name</td>
<td><input name="foname" type="text" pattern="[A-Za-z A-Za-z]*" id="textbox" required/></td>
</tr>
<tr>



		
	  <tr><td colspan="2"><br><center><button type='submit' style='width:200;background-color:SpringGreen;'>SUBMIT</button></center></td></tr>

	  </table></center>
</form>

<br><br><br>

	</div>
  </div>
</div>

	<center>
	 <div id='footer'>
	<b><p>Copyright &copy; 2014 Foreign Exchange Market And Rates Trading System</p></b>
	</div>
	</center>
	
</html>