<html>
<head>
<meta http-equiv='content-type' content='text/html; charset=utf-8'/><title>View Customers</title>
<meta name='keywords' content=''/><meta name='description' content=''/>

<link href='style.css' rel='stylesheet' type='text/css' media='screen'/>

</head>
<body>
<div id='header'>
</div>

<div id='menu'>
		
		<center><ul>

		<li class="first"><a href="index.php">HOME</a></li>
		<li><a href="viewcustomer.php">CUSTOMERS</a></li>
		<li><a href="rate.php">SELLING RATES</a></li>
		<li><a href="delivery.php">BUYING RATES</a></li>
		<li><a href="viewtrans.php">TRANSACTIONS</a></li>
		</ul></center>


</div>

<div id='page'>
	<div style='background-color:WHITE'>

<br>
<center><font color=blue size=5 face=impact>VIEW Rates</font></center>
<br>
<hr color="#006600">

				<table cellpadding="3" cellspacing="0"  width="780" class="mytable" align="center">
			<thead>
				<tr>
					<th  style="border-left: 1px solid #C1DAD7"> Symbol </th>
					<th> Curency </th>
					
					<th> Sell Rate </th>
					<th> Forex Name </th>
					<th> Action </th>
				</tr>
			</thead>
			<tbody>
			<?php	include('db.php');
				//$userid= $_SESSION['SESS_MEMBER_ID'];
				
				$result = mysql_query("SELECT * FROM buy order by Buyrate asc");
				//$result1 = mysql_query("SELECT * FROM sale order by rate asc");
				while($row = mysql_fetch_array($result))
					{
						//$row1 = mysql_fetch_array($result1);
						echo '<tr>';
						echo '<td style="border-left: 1px solid #C1DAD7;">'.$row['Symbol'].'</td>';
						echo '<td>'.$row['Currency'].'</td>';
						///echo '<td>'.$row['rate'].'</td>';
						echo '<td>'.$row['Buyrate'].'</td>';
						
						echo '<td>'.$row['ForexName'].'</td>';
						echo '<td><div align="center"><a rel="facebox" href="edit.php?id='.$row['id'].'" title="Click To Edit"><img src="images/edit.gif"></a>';
						if($_SESSION['SESS_FIRST_NAME']=="1"){
						echo '| <a href="#" id="'.$row['id'].'" class="delbutton" title="Click To Delete"><img src="images/delete.gif"></a>';
						}
						echo '</div></td>';
						echo '</tr>';
					}
				?> 
			</tbody>
		</table>
</div>
  
<br><br><br>

	</div>
  </div>
</div>

	<center>
	 <div id='footer'>
	<b><p>Copyright &copy; 2014 Foreign Exchange Market And Rates Trading System </p></b>
	</div>
	</center>
	</body>
</html>