<?php
require("connect.php");
if(isset($_POST['submit'])){
$username=$_POST['username'];
$password=$_POST['password'];
$position=$_POST['status'];
if($position=='1'){
$result=mysql_query("SELECT * FROM users WHERE username='$username' AND password='$password' AND status='1'");
$row=mysql_num_rows($result);
if($row>0){


header("location:home.php");
}
else{
echo "fail".mysql_error();
}
}

elseif($position='2'){
$result=mysql_query("SELECT * FROM users WHERE username='$username' AND password='$password' AND status='2'");
$row=mysql_num_rows($result);
if($row>0){

header("location:home1.php");
}else{
echo "<font color=red>Invalid login Try Again</font>";
}

}
}
?>
