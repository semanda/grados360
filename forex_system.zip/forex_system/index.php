<?php ob_start();?>
<html>
<head>
<meta http-equiv='content-type' content='text/html; charset=utf-8'/><title>Foreign Exchange Market And Rates Trading System</title>
<meta name='keywords' content=''/><meta name='description' content=''/>

<link href='style.css' rel='stylesheet' type='text/css' media='screen'/>

</head>
<body>
<div id='header'>
</div>

<div id='menu'>
		
		<center><ul>

		
		</ul></center>

</div>

<div id='page'>
	<div style='background-color:WHITE'>

	<br>
	
<form action='' method='POST'>

<center><font color=blue size=5 face=impact>LOGIN ACCESS</font></center>

<br>

<table width='730' border='2' cellpadding='0' cellspacing='20' bgcolor='white' align='center'> 


<center><font color="DarkOliveGreen" size=4 face=impact>Type : </font>
		<select name='status' width='1'>
			<option value='1' SELECTED>Primary Administrator</option>
			<option value='2'><b>Secondary Administrator</option></select>


<center><br><font color=black size=4 face=impact>username : </font>
			<input type='text' name='username'>

<center><font color=black size=4 face=impact>password : </font>
		<input type='password' name='password'>
		

		
	  <br><br><center><button type='submit' style='width:200;background-color:SpringGreen;' name="submit">SUBMIT</button></center>

	  </table>
</form>

<br><br><br>

	</div>
  </div>
</div>

	<center>
	 <div id='footer'>
	<b><p>Copyright &copy; 2014 Foreign Exchange Market And Rates Trading System</p></b>
	</div>
	</center>
	
</html>
<?php

require("./connect.php");
if(isset($_POST['submit'])){
$username=$_POST['username'];
$password=$_POST['password'];
$position=$_POST['status'];
if($position=='1'){
$result=mysql_query("SELECT * FROM users WHERE username='$username' AND password='$password' AND status='1'");
$row=mysql_num_rows($result);
if($row>0){


header("location:home.php");
}

}

elseif($position='2'){
$result=mysql_query("SELECT * FROM users WHERE username='$username' AND password='$password' AND status='2'");
$row=mysql_num_rows($result);
if($row>0){

header("location:home1.php");
}
}else{
echo "<font color=red>Invalid login Try Again</font>";
}
}


?>
