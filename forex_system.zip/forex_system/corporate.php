<? session_start();


if($_SESSION['utype']=='Primary')
{
require("admin.php");
}

else
{
require("branch.php");
}


?>

<html>
<head>
<meta http-equiv='content-type' content='text/html; charset=utf-8'/><title>Customer Entry</title>
<meta name='keywords' content=''/><meta name='description' content=''/>

<link href='style.css' rel='stylesheet' type='text/css' media='screen'/>
<script type="text/javascript">
function validateForm()
{
var x=document.forms["myForm"]["fname"].value;
if (x==null || x=="")
  {
  alert("First name must be filled out");
  return false;
  }
var x=document.forms["myForm"]["lname"].value;
if (x==null || x=="")
  {
  alert("Last name must be filled out");
  return false;
  }
var x=document.forms["myForm"]["contact"].value;
if (x==null || x=="")
  {
  alert("Phone Number must be filled out");
  return false;
  }
var x=document.forms["myForm"]["country"].value;
if (x==null || x=="")
  {
  alert("Country must be filled out");
  return false;
  }
var x=document.forms["myForm"]["city"].value;
if (x==null || x=="")
  {
  alert("City must be filled out");
  return false;
  }
var x=document.forms["myForm"]["address"].value;
if (x==null || x=="")
  {
  alert("Address must be filled out");
  return false;
  }
var x=document.forms["myForm"]["gender"].value;
if (x==null || x="")
  {
  alert("gender must be filled out");
  return false;
  }
}
</script>

</head>
<body>
<div id='header'>
</div>

<div id='menu'>
		
		<center><ul>

<li class="first"><a href="home.php">HOME</a></li>
		<li><a href="corporate.php">CUSTOMERS</a></li>
		<li><a href="rate.php">RATES</a></li>
		<li><a href="delivery.php">TRANSACTIONS</a></li>
		<li><a href="news.php">REPORTS</a></li>
		<li><a href="operations.php">OPERATIONS</a></li>
		</ul></center>

</div>

<div id='page'>
	<div style='background-color:WHITE'>

<br>
<center><font color=blue size=5 face=impact>CUSTOMERS REGISTRATION</font></center>
<br>
<hr color="#006600">
<form name="myForm" action="addcust.php" method="post" enctype="multipart/form-data" name="addroom" onsubmit="return validateForm()">
<center><table width='730' border='0' cellpadding='4' cellspacing='10' align='center'> 

<tr>
<td>First Name: </td>
<td><input name="fname" type="text" id="textbox"/></td>
</tr>
<tr>
<td>Last Name: </td>
<td><input name="lname" type="text" onKeyPress="return isNumberKey(event)" id="textbox" /></td>
</tr>
<tr>
<td>Phone: </td>
<td><input name="contact" type="text" onKeyPress="return isNumberKey(event)" id="textbox" /></td>
</tr>
<tr>
<td>Country: </td>
<td><input name="country" type="text" onKeyPress="return isNumberKey(event)" id="textbox" /></td>
</tr>
<tr>
<td>City: </td>
<td><input name="city" type="text" onKeyPress="return isNumberKey(event)" id="textbox" /></td>
</tr>
<tr>
<td>Address </td>
<td><input name="address" type="text" id="textbox" /></td>
</tr>
<tr>
<td>Gender </td>
<td><select name="gender">
<option>------------Select Gender---------------</option>
<option value="Male">Male</option>
<option value="Female">Female</option>
</select></td>
</tr>


		
	  <tr><td colspan="2"><br><center><button type='submit' style='width:200;background-color:SpringGreen;'>SUBMIT</button></center></td></tr>

	  </table></center>
</form>

<br><br><br>

	</div>
  </div>
</div>

	<center>
	 <div id='footer'>
	<b><p>Copyright &copy; 2014 Foreign Exchange Market And Rates Trading System</p></b>
	</div>
	</center>
	
</html>