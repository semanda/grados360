<html>
<head>
<meta http-equiv='content-type' content='text/html; charset=utf-8'/><title>View Customers</title>
<meta name='keywords' content=''/><meta name='description' content=''/>

<link href='style.css' rel='stylesheet' type='text/css' media='screen'/>

</head>
<body>
<div id='header'>
</div>

<div id='menu'>
		
		<center><ul>

		<li class="first"><a href="home.php">HOME</a></li>
		<li><a href="viewcustomer.php">CUSTOMERS</a></li>
		<li><a href="rate.php">SELLING RATES</a></li>
		<li><a href="delivery.php">BUYING RATES</a></li>
		<li><a href="viewtrans.php">TRANSACTIONS</a></li>
		</ul></center>

</div>

<div id='page'>
	<div style='background-color:WHITE'>

<br>
<center><font color=blue size=5 face=impact>VIEW CUSTOMERS</font></center>
<br>
<hr color="#006600">

				<table cellpadding="3" cellspacing="0"  width="780" class="mytable" align="center">
			<thead>
				<tr>
					<th  style="border-left: 1px solid #C1DAD7"> Name </th>
					<th> Contact </th>
					<th> Country </th>
					<th> City </th>
					<th> Address </th>
					<th> Gender </th>
					<th> Action </th>
				</tr>
			</thead>
			<tbody>
			<?php	include('db.php');
				//$userid= $_SESSION['SESS_MEMBER_ID'];
				$result = mysql_query("SELECT * FROM customer order by Fname asc");
				while($row = mysql_fetch_array($result))
					{
						echo '<tr>';
						echo '<td style="border-left: 1px solid #C1DAD7;">'.$row['Fname']. ' ' .$row['Lname'].'</td>';
						echo '<td>'.$row['Phone'].'</td>';
						echo '<td>'.$row['Country'].'</td>';
						echo '<td>'.$row['City'].'</td>';
						echo '<td>'.$row['Address'].'</td>';
						echo '<td>'.$row['Gender'].'</td>';
						echo '<td><div align="center"><a rel="facebox" href="edit.php?id='.$row['id'].'" title="Click To Edit"><img src="images/edit.gif"></a>';
						if($_SESSION['SESS_FIRST_NAME']=="1"){
						echo '| <a href="#" id="'.$row['id'].'" class="delbutton" title="Click To Delete"><img src="images/delete.gif"></a>';
						}
						echo '</div></td>';
						echo '</tr>';
					}
				?> 
			</tbody>
		</table>
</div>
  
<br><br><br>

	</div>
  </div>
</div>

	<center>
	 <div id='footer'>
	<b><p>Copyright &copy; 2014 Foreign Exchange Market And Rates Trading System </p></b>
	</div>
	</center>
	</body>
</html>